import React, { useRef, useState } from 'react' ; 
import { doAjax } from '../utils/ajax' ; 
import { DashBoard } from './Dashboard';
import { Admin_dashboard } from './Admin_dashboard';

export const Login =()=>{
    const userid = useRef(''); 
    const password =useRef('') ; 
    const[message , setMessage] = useState(''); 

    const doLogin =()=>{
        
        let uid = userid.current.value ; 
        let pwd = password.current.value ; 
        const userObject = {"userid":uid , "password":pwd} ; 
        const json = JSON.stringify(userObject) ; 
        console.log('JSON is --------- ', json, ' Object is----- ',userObject );
        const promise = doAjax('http://localhost:1234/login' ,'POST' , json) ;
        promise.then(response =>{
            response.json().then(data=>{
                setMessage(data.message) ; 
            }).catch(error =>{
                console.log("----------------------invalid JSON " , error) ; 
            })
        }).catch(err=>{
            console.log("Error on Server Call " , err) ; 
        })
    }
    if(message.startsWith("Welcome")){
       // return(<h1>Success</h1>)
       console.log("------------YESSSSSSSSSSSSSSSSSSSSSSSSSS") ; 
         return (<Admin_dashboard msg = {message}/>)
    }
    else{
        console.log("NOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO") ; 
        return(
            <>
        <h2>{message}</h2>
        <div className='form-group'>
            <label>Userid</label>
            <input ref={userid} className='form-control' type='text' placeholder='Type Userid Here'/>
        </div>
        <div className='form-group'>
            <label>Password</label>
            <input ref={password} className='form-control' type='password' placeholder='Type Password Here'/>
        </div>
        <div className='form-group'>
            <button onClick={doLogin} className='btn btn-primary'>Login</button>
            &nbsp;&nbsp;
            <button className='btn btn-secondary'>Reset</button>                
        </div>
    </>
        )
    }
}
